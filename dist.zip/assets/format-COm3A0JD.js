function t(r){return r==null?"-":`${r.toLocaleString("ja-JP")}円`}function e(r){return r?r.slice(0,10):"-"}export{e as a,t as f};
